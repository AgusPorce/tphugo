import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';

const BlogCard = ({ post, onOpen }) => {
  const { title, description, date, read_time, image_url, alt_text } = post;
  return (
    <motion.div
      whileHover={{ y: -5, boxShadow: "0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)" }}
      transition={{ type: "spring", stiffness: 300 }}
      onClick={() => onOpen(post)}
      className="cursor-pointer"
    >
      <Card className="overflow-hidden bg-white rounded-2xl shadow-lg border-none h-full flex flex-col">
        <img alt={alt_text} className="w-full h-48 object-cover" src={image_url} />
        <CardContent className="p-6 flex flex-col flex-grow">
          <h3 className="text-xl font-bold text-blue-900 mb-2">{title}</h3>
          <p className="text-gray-600 mb-4 text-sm leading-relaxed flex-grow">{description}</p>
          <div className="flex justify-between items-center text-xs text-gray-500 mt-auto">
            <span>{date}</span>
            <span>{read_time}</span>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

const DocumentationSection = () => {
  const [selectedBlog, setSelectedBlog] = useState(null);
  const [faqItems, setFaqItems] = useState([]);
  const [blogPosts, setBlogPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const { data: faqs, error: faqsError } = await supabase.from('faq_items').select('*').order('id');
        if (faqsError) throw faqsError;
        setFaqItems(faqs);

        const { data: blogs, error: blogsError } = await supabase.from('blog_posts').select('*').order('created_at');
        if (blogsError) throw blogsError;
        setBlogPosts(blogs);
      } catch (error) {
        console.error("Error fetching data from Supabase:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleCloseDialog = () => {
    setSelectedBlog(null);
    document.getElementById('documentacion')?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const renderContent = (post) => {
    if (!post) return null;

    if (post.id === 'bitacora-proyecto' && post.content_type === 'structured' && post.structured_content?.items) {
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {post.structured_content.items.map((item, index) => (
            <div key={index}>
              <h4 className="text-xl font-bold text-blue-800 mb-2">{item.title}</h4>
              <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">{item.text}</p>
            </div>
          ))}
        </div>
      );
    }
    
    return (
       <div className="prose max-w-none">
          <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">{post.text_content}</p>
       </div>
    );
  };


  return (
    <>
      <section className="py-16 sm:py-24 bg-slate-100">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.6 }}
          >
            <div className="text-left mb-12">
              <span className="inline-block bg-blue-600 text-white text-sm font-semibold px-4 py-1 rounded-full mb-2">Sección</span>
              <h2 className="text-3xl sm:text-4xl font-bold text-blue-900">Documentación</h2>
              <p className="mt-2 text-lg text-gray-600">Explora los detalles, el proceso y las preguntas sobre nuestro proyecto.</p>
            </div>

            {loading ? (
              <div className="flex justify-center items-center h-64">
                <Loader2 className="h-12 w-12 animate-spin text-blue-600" />
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
                  {blogPosts.map((post) => (
                    <BlogCard key={post.id} post={post} onOpen={setSelectedBlog} />
                  ))}
                </div>

                <div className="max-w-4xl mx-auto">
                  <h3 className="text-2xl sm:text-3xl font-bold text-blue-900 text-center mb-8">Preguntas Frecuentes</h3>
                  <Accordion type="single" collapsible className="w-full">
                    {faqItems.map((item) => (
                      <AccordionItem value={`item-${item.id}`} key={item.id} className="bg-white border-b border-gray-200 rounded-lg mb-3 shadow-sm">
                        <AccordionTrigger className="text-blue-800 font-semibold text-left p-6 hover:no-underline">
                          {item.question}
                        </AccordionTrigger>
                        <AccordionContent className="p-6 pt-0">
                          <p className="text-gray-700 leading-relaxed">{item.answer}</p>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </div>
              </>
            )}
          </motion.div>
        </div>
      </section>

      <Dialog open={!!selectedBlog} onOpenChange={() => setSelectedBlog(null)}>
        <DialogContent className="sm:max-w-4xl bg-white rounded-2xl flex flex-col max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="text-3xl font-bold text-blue-900">{selectedBlog?.title}</DialogTitle>
            <DialogDescription className="text-md text-gray-600 pt-2 pb-4">
              {selectedBlog?.description}
              <p className="text-sm text-gray-500 pt-2">{selectedBlog?.date} &middot; {selectedBlog?.read_time}</p>
            </DialogDescription>
          </DialogHeader>
          <div className="flex-grow overflow-y-auto pr-4 -mr-4">
            {selectedBlog?.id !== 'bitacora-proyecto' && selectedBlog?.image_url && 
              <img alt={selectedBlog?.alt_text} className="w-full h-64 object-cover rounded-lg mb-6" src={selectedBlog.image_url} />}
            {renderContent(selectedBlog)}
          </div>
          <DialogFooter className="pt-4">
            <Button onClick={handleCloseDialog} variant="outline" className="bg-blue-600 text-white hover:bg-blue-700 hover:text-white">
              <ArrowLeft className="mr-2 h-4 w-4" /> Volver a Documentación
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default DocumentationSection;