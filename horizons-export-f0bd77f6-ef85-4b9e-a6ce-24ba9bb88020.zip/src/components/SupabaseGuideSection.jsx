import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Database, User, Shield, Folder, AlertTriangle } from 'lucide-react';

const CodeBlock = ({ children }) => (
  <pre className="bg-gray-800 text-white p-4 rounded-lg mt-4 overflow-x-auto text-sm">
    <code>{children}</code>
  </pre>
);

const GuideCard = ({ icon, title, children }) => (
  <Card className="bg-white rounded-2xl shadow-lg border-none h-full">
    <CardHeader className="flex flex-row items-center gap-4">
      {icon}
      <CardTitle className="text-blue-900">{title}</CardTitle>
    </CardHeader>
    <CardContent className="text-gray-700">
      {children}
    </CardContent>
  </Card>
);

const SupabaseGuideSection = () => {
  return (
    <section id="guia-supabase" className="py-16 sm:py-24 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6 }}
        >
          <div className="text-center mb-12">
            <span className="inline-block bg-green-600 text-white text-sm font-semibold px-4 py-1 rounded-full mb-2">Guía Rápida</span>
            <h2 className="text-3xl sm:text-4xl font-bold text-blue-900">Integración con Supabase</h2>
            <p className="mt-2 text-lg text-gray-600 max-w-3xl mx-auto">
              Aquí tienes ejemplos prácticos para interactuar con tu base de datos y gestionar usuarios.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            
            {/* CRUD Card */}
            <div className="lg:col-span-2">
              <GuideCard icon={<Database className="w-8 h-8 text-green-500" /> } title="Operaciones CRUD">
                <p>Interactúa con tus tablas usando una sintaxis simple y poderosa. Ya estás usando `select` para leer datos. Aquí tienes cómo crear, actualizar y eliminar.</p>
                <CodeBlock>
{`// Crear (Create)
const { data, error } = await supabase
  .from('blog_posts')
  .insert([
    { title: 'Nuevo Post', description: 'Contenido...' },
  ]);

// Actualizar (Update)
const { data, error } = await supabase
  .from('blog_posts')
  .update({ title: 'Título Actualizado' })
  .eq('id', 'id-del-post');

// Eliminar (Delete)
const { data, error } = await supabase
  .from('blog_posts')
  .delete()
  .eq('id', 'id-del-post');`}
                </CodeBlock>
              </GuideCard>
            </div>

            {/* Auth Card */}
            <GuideCard icon={<User className="w-8 h-8 text-green-500" />} title="Autenticación">
              <p>Gestiona el registro e inicio de sesión de usuarios de forma segura. El `AuthProvider` ya está configurado.</p>
              <CodeBlock>
{`// Registrar un nuevo usuario
const { data, error } = await supabase.auth.signUp({
  email: 'test@example.com',
  password: 'super-secreto',
});

// Iniciar sesión
const { data, error } = await supabase.auth.signInWithPassword({
  email: 'test@example.com',
  password: 'super-secreto',
});

// Cerrar sesión
const { error } = await supabase.auth.signOut();`}
              </CodeBlock>
            </GuideCard>

            {/* RLS Card */}
            <GuideCard icon={<Shield className="w-8 h-8 text-green-500" />} title="Row-Level Security (RLS)">
              <p>RLS te permite definir políticas de acceso a nivel de fila. Por ejemplo, "los usuarios solo pueden ver sus propios posts". ¡Ya tienes políticas activas en algunas tablas!</p>
              <p className="mt-2 font-semibold">Es una capa de seguridad fundamental en Supabase.</p>
            </GuideCard>

            {/* Storage Card */}
            <GuideCard icon={<Folder className="w-8 h-8 text-green-500" />} title="Almacenamiento">
              <p>Sube, descarga y gestiona archivos como imágenes o documentos en los "buckets" de Supabase.</p>
              <CodeBlock>
{`// Subir un archivo
const { data, error } = await supabase.storage
  .from('avatars') // Nombre del bucket
  .upload('public/avatar1.png', file);

// Descargar un archivo
const { data, error } = await supabase.storage
  .from('avatars')
  .download('public/avatar1.png');`}
              </CodeBlock>
            </GuideCard>

            {/* Error Handling Card */}
            <GuideCard icon={<AlertTriangle className="w-8 h-8 text-green-500" />} title="Manejo de Errores">
              <p>Cada operación de Supabase devuelve un objeto `data` y un objeto `error`. ¡Siempre comprueba si `error` existe!</p>
              <CodeBlock>
{`const { data, error } = await supabase
  .from('blog_posts')
  .select('*');

if (error) {
  console.error('¡Hubo un error!', error);
  // Muestra una notificación al usuario
} else {
  // Todo salió bien, usa la 'data'
  console.log(data);
}`}
              </CodeBlock>
            </GuideCard>

          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default SupabaseGuideSection;