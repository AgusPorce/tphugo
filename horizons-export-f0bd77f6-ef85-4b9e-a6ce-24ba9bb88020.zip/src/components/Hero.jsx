import React from 'react';
import { motion } from 'framer-motion';
import { Vote, Calendar, Users } from 'lucide-react';
const Hero = () => {
  return <section id="inicio" className="pt-24 pb-16 px-4">
      <div className="container mx-auto">
        <motion.div initial={{
        opacity: 0,
        y: 30
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8
      }} className="text-center max-w-4xl mx-auto">
          <div className="mb-8">
            <img alt="Bandera de Argentina ondeando" className="w-full h-64 object-cover rounded-2xl shadow-2xl" src="https://horizons-cdn.hostinger.com/f0bd77f6-ef85-4b9e-a6ce-24ba9bb88020/frente-final-BwfMR.png" />
          </div>

          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-sky-600 via-sky-400 to-sky-600 bg-clip-text text-transparent">Proyecto ILS</h1>

          <p className="text-xl md:text-2xl text-gray-700 mb-8 leading-relaxed">Muestra 2025 Administración y Gestión de Bases de Datos</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            <motion.div whileHover={{
            scale: 1.05
          }} className="bg-white p-6 rounded-xl shadow-lg border-2 border-sky-100">
              <Calendar className="w-12 h-12 text-sky-600 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-gray-800 mb-2">Fecha Electoral</h3>
              <p className="text-gray-600">Octubre 2025</p>
            </motion.div>

            <motion.div whileHover={{
            scale: 1.05
          }} className="bg-white p-6 rounded-xl shadow-lg border-2 border-sky-100">
              <Users className="w-12 h-12 text-sky-600 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-gray-800 mb-2">Candidatos</h3>
              <p className="text-gray-600">Múltiples partidos</p>
            </motion.div>

            <motion.div whileHover={{
            scale: 1.05
          }} className="bg-white p-6 rounded-xl shadow-lg border-2 border-sky-100">
              <Vote className="w-12 h-12 text-sky-600 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-gray-800 mb-2">Sistema Electoral</h3>
              <p className="text-gray-600">Voto obligatorio</p>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>;
};
export default Hero;