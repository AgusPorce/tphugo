import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, CheckCircle } from 'lucide-react';

const TimelineSection = () => {
  const timeline = [
    {
      date: 'Marzo 2025',
      event: 'Inicio de campaña electoral',
      description: 'Comienzan oficialmente las campañas de los candidatos'
    },
    {
      date: 'Junio 2025',
      event: 'Cierre de listas',
      description: 'Fecha límite para la presentación de candidaturas'
    },
    {
      date: 'Agosto 2025',
      event: 'Elecciones PASO',
      description: 'Primarias Abiertas Simultáneas y Obligatorias'
    },
    {
      date: 'Octubre 2025',
      event: 'Elecciones Generales',
      description: 'Primera vuelta electoral presidencial'
    },
    {
      date: 'Noviembre 2025',
      event: 'Posible Ballotage',
      description: 'Segunda vuelta si ningún candidato supera el 45%'
    },
    {
      date: 'Diciembre 2025',
      event: 'Asunción del mando',
      description: 'El nuevo presidente asume sus funciones'
    }
  ];

  return (
    <section id="cronograma" className="py-16 px-4 bg-white">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Cronograma Electoral</h2>
          <p className="text-xl text-gray-600">Fechas importantes del proceso electoral 2025</p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          {timeline.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="relative mb-8 last:mb-0"
            >
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-sky-600 rounded-full flex items-center justify-center shadow-lg">
                    <CheckCircle className="w-6 h-6 text-white" />
                  </div>
                </div>
                <div className="flex-grow bg-gradient-to-r from-sky-50 to-white p-6 rounded-xl shadow-lg border-l-4 border-sky-600">
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="w-5 h-5 text-sky-600" />
                    <span className="text-sky-600 font-bold">{item.date}</span>
                  </div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{item.event}</h3>
                  <p className="text-gray-600">{item.description}</p>
                </div>
              </div>
              {index < timeline.length - 1 && (
                <div className="absolute left-6 top-12 bottom-0 w-0.5 bg-sky-200 -mb-8"></div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TimelineSection;