import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from "@/components/ui/use-toast";

const ProjectSection = () => {
  const { toast } = useToast();

  const handleDocsClick = () => {
    const docSection = document.getElementById('documentacion');
    if (docSection) {
      docSection.scrollIntoView({ behavior: 'smooth' });
    } else {
      toast({
        title: "🚧 Sección no encontrada",
        description: "Parece que hay un problema al navegar a la documentación. ¡Lo revisaremos!",
      });
    }
  };

  return (
    <section id="proyecto" className="py-16 sm:py-24 bg-slate-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex flex-col sm:flex-row items-center justify-between mb-8 gap-4 text-center sm:text-left">
            <h2 className="text-3xl sm:text-4xl font-bold text-blue-900">Nuestro Proyecto Educativo</h2>
            <img alt="Logo del Instituto La Salette" className="w-16 h-16 sm:w-20 sm:h-20" src="https://horizons-cdn.hostinger.com/f0bd77f6-ef85-4b9e-a6ce-24ba9bb88020/unnamed-7yWhG.png" />
          </div>
          <p className="text-lg text-gray-700 leading-relaxed mb-10 max-w-3xl mx-auto sm:mx-0">
            Un grupo de estudiantes comprometidos con la investigación y simulación electoral en la comuna 12, utilizando datos históricos y herramientas de <span className="font-semibold text-blue-600">base de datos</span> para un análisis profundo.
          </p>

          <div className="mb-10">
            <motion.div whileHover={{ scale: 1.03 }} className="overflow-hidden rounded-2xl shadow-xl">
              <img alt="Estudiantes trabajando en computadoras" className="w-full h-auto object-cover" src="https://horizons-cdn.hostinger.com/f0bd77f6-ef85-4b9e-a6ce-24ba9bb88020/1000300326-TrOVV.jpg" />
            </motion.div>
          </div>
          
          <div className="flex items-center justify-center">
            <Button onClick={handleDocsClick} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 text-lg rounded-full transition-transform transform hover:scale-105">
              Ir a Documentación
            </Button>
          </div>

        </motion.div>
      </div>
    </section>
  );
};

export default ProjectSection;