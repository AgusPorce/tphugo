import React from 'react';
import { motion } from 'framer-motion';
import { Info, CheckCircle, AlertCircle } from 'lucide-react';

const InfoSection = () => {
  const infoCards = [
    {
      icon: CheckCircle,
      title: '¿Quiénes pueden votar?',
      description: 'Todos los ciudadanos argentinos mayores de 16 años. El voto es obligatorio entre 18 y 70 años.',
      color: 'sky'
    },
    {
      icon: Info,
      title: 'Sistema de votación',
      description: 'Se utiliza el sistema de boleta única papel en algunas provincias y boletas partidarias en otras.',
      color: 'blue'
    },
    {
      icon: AlertCircle,
      title: 'Documentación necesaria',
      description: 'DNI vigente. Verificá tu lugar de votación con anticipación en el padrón electoral.',
      color: 'indigo'
    }
  ];

  return (
    <section className="py-16 px-4 bg-gradient-to-b from-white to-sky-50">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Información Electoral</h2>
          <p className="text-xl text-gray-600">Todo lo que necesitás saber para ejercer tu derecho al voto</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {infoCards.map((card, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              whileHover={{ y: -10 }}
              className={`bg-white p-8 rounded-2xl shadow-xl border-t-4 border-${card.color}-500`}
            >
              <card.icon className={`w-16 h-16 text-${card.color}-600 mb-4`} />
              <h3 className="text-2xl font-bold text-gray-800 mb-3">{card.title}</h3>
              <p className="text-gray-600 leading-relaxed">{card.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default InfoSection;