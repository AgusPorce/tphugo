import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Star } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";
const HeroNew = () => {
  const {
    toast
  } = useToast();
  const handleDiscoverMore = () => {
    const projectSection = document.getElementById('proyecto');
    if (projectSection) {
      projectSection.scrollIntoView({
        behavior: 'smooth'
      });
    }
  };
  return <section id="inicio" className="relative h-screen min-h-[600px] w-full text-white">
      <div className="absolute inset-0 z-0">
        <img alt="Fachada del Instituto La Salette" class="w-full h-full object-cover" src="https://horizons-cdn.hostinger.com/f0bd77f6-ef85-4b9e-a6ce-24ba9bb88020/frente-final-LfbAY.png" />
        <div className="absolute inset-0 bg-black/50"></div>
      </div>
      <div className="relative z-10 flex flex-col items-center justify-center h-full text-center px-4">
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8
      }}>
          <h1 className="text-5xl md:text-6xl font-bold tracking-tight">Proyecto ILS</h1>
          <p className="mt-2 text-3xl md:text-4xl font-light tracking-wide">MUESTRA 2025</p>
          <div className="mt-6 max-w-xl mx-auto">
             <p className="text-blue-200 text-sm md:text-base">Administración y Gestión de Bases de Datos</p>
             <p className="text-sm md:text-base">2º Año Ciclo Superior Especialidad Computación</p>
             <p className="mt-4 text-base md:text-lg">
                Un proyecto académico sobre elecciones legislativas nacionales con datos históricos y proyecciones.
             </p>
          </div>
          <Button onClick={handleDiscoverMore} className="mt-8 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full text-lg transition-transform transform hover:scale-105">
            Descubre más
          </Button>
          <div className="mt-6 flex flex-col items-center">
             <div className="flex space-x-1 text-yellow-400">
                {[...Array(5)].map((_, i) => <Star key={i} fill="currentColor" className="w-5 h-5" />)}
             </div>
             <p className="mt-2 text-sm font-semibold tracking-widest">INNOVADOR Y EDUCATIVO</p>
          </div>
        </motion.div>
      </div>
    </section>;
};
export default HeroNew;