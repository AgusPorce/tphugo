import React from 'react';
import { motion } from 'framer-motion';
import { User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const CandidatesSection = () => {
  const { toast } = useToast();

  const candidates = [
    {
      name: 'Candidato A',
      party: 'Partido Político 1',
      description: 'Propuestas enfocadas en economía y desarrollo social'
    },
    {
      name: 'Candidato B',
      party: 'Partido Político 2',
      description: 'Enfoque en educación y tecnología'
    },
    {
      name: 'Candidato C',
      party: 'Partido Político 3',
      description: 'Prioridad en seguridad y justicia'
    },
    {
      name: 'Candidato D',
      party: 'Partido Político 4',
      description: 'Propuestas de salud y medio ambiente'
    }
  ];

  const handleLearnMore = () => {
    toast({
      title: "🚧 Esta función aún no está implementada",
      description: "¡Pero no te preocupes! Podés solicitarla en tu próximo mensaje 🚀",
    });
  };

  return (
    <section id="candidatos" className="py-16 px-4 bg-white">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Candidatos Presidenciales</h2>
          <p className="text-xl text-gray-600">Conocé las propuestas de los principales candidatos</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {candidates.map((candidate, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              className="bg-gradient-to-br from-sky-50 to-white p-6 rounded-xl shadow-lg border border-sky-200"
            >
              <div className="flex justify-center mb-4">
                <div className="w-24 h-24 bg-sky-100 rounded-full flex items-center justify-center">
                  <User className="w-12 h-12 text-sky-600" />
                </div>
              </div>
              <h3 className="text-xl font-bold text-gray-800 text-center mb-2">{candidate.name}</h3>
              <p className="text-sky-600 text-center font-semibold mb-3">{candidate.party}</p>
              <p className="text-gray-600 text-center text-sm mb-4">{candidate.description}</p>
              <Button 
                onClick={handleLearnMore}
                className="w-full bg-sky-600 hover:bg-sky-700 text-white"
              >
                Ver propuestas
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CandidatesSection;