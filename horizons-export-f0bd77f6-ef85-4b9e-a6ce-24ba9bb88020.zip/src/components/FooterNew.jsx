import React from 'react';
import { Plus, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from "@/components/ui/use-toast";

const FooterNew = () => {
    const { toast } = useToast();

    const handleAction = () => {
        toast({
            title: "🚧 Esta función aún no está implementada",
            description: "¡Pero no te preocupes! Podés solicitarla en tu próximo mensaje 🚀",
        });
    };

    const handleScrollTop = () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    return (
        <footer className="fixed bottom-4 right-4 left-4 z-50 flex justify-between items-center">
            <div/>
            <div className="flex gap-2">
                <Button size="icon" className="rounded-full bg-blue-600 hover:bg-blue-700 w-14 h-14 shadow-lg" onClick={handleAction}>
                    <Plus className="w-8 h-8"/>
                    <span className="sr-only">Agregar</span>
                </Button>
                <Button size="icon" className="rounded-full bg-blue-600 hover:bg-blue-700 w-14 h-14 shadow-lg" onClick={handleScrollTop}>
                    <div className="flex flex-col items-center">
                        <ChevronUp className="w-5 h-5 -mb-2"/>
                        <ChevronDown className="w-5 h-5"/>
                    </div>
                    <span className="sr-only">Desplazar</span>
                </Button>
            </div>
        </footer>
    );
};

export default FooterNew;