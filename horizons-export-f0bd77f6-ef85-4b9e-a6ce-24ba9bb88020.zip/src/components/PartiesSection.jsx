import React from 'react';
import { motion } from 'framer-motion';
import { Flag } from 'lucide-react';

const PartiesSection = () => {
  const parties = [
    {
      name: 'Unión por la Patria',
      color: 'from-blue-500 to-blue-700',
      ideology: 'Centro-izquierda'
    },
    {
      name: 'Juntos por el Cambio',
      color: 'from-yellow-400 to-yellow-600',
      ideology: 'Centro-derecha'
    },
    {
      name: 'La Libertad Avanza',
      color: 'from-violet-500 to-violet-700',
      ideology: 'Derecha liberal'
    },
    {
      name: 'Frente de Izquierda',
      color: 'from-red-500 to-red-700',
      ideology: 'Izquierda'
    },
    {
      name: 'Hacemos por Nuestro País',
      color: 'from-teal-500 to-teal-700',
      ideology: 'Centro'
    },
    {
      name: 'Otros Partidos',
      color: 'from-gray-500 to-gray-700',
      ideology: 'Diversas tendencias'
    }
  ];

  return (
    <section id="partidos" className="py-16 px-4 bg-gradient-to-b from-sky-50 to-white">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Partidos Políticos</h2>
          <p className="text-xl text-gray-600">Principales fuerzas políticas en competencia</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {parties.map((party, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              className="bg-white p-6 rounded-xl shadow-lg border-2 border-gray-100 overflow-hidden relative"
            >
              <div className={`absolute top-0 left-0 right-0 h-2 bg-gradient-to-r ${party.color}`}></div>
              <Flag className="w-12 h-12 text-gray-700 mb-4 mt-2" />
              <h3 className="text-xl font-bold text-gray-800 mb-2">{party.name}</h3>
              <p className="text-gray-600">{party.ideology}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PartiesSection;