import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header';
import HeroNew from '@/components/HeroNew';
import ProjectSection from '@/components/ProjectSection';
import DocumentationSection from '@/components/DocumentationSection';
import SupabaseGuideSection from '@/components/SupabaseGuideSection';
import FooterNew from '@/components/FooterNew';

function App() {
  const handleNavClick = (sectionId) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <>
      <Helmet>
        <title>Proyecto ILS - Muestra AYGBD 2025</title>
        <meta name="description" content="Proyecto académico ILS sobre elecciones legislativas. Administración y Gestión de Bases de Datos, 2º Año Ciclo Superior." />
      </Helmet>
      <div className="min-h-screen bg-slate-50">
        <Header onNavClick={handleNavClick} />
        <main>
          <div id="inicio">
            <HeroNew />
          </div>
          <div id="proyecto">
            <ProjectSection />
          </div>
          <div id="documentacion">
            <DocumentationSection />
          </div>
          <div id="guia-supabase">
            <SupabaseGuideSection />
          </div>
        </main>
        <FooterNew />
      </div>
    </>
  );
}

export default App;